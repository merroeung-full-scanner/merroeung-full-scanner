MERROEUNG FULL MEMBER SCANNER — STEP 3
========================================

គោលបំណង
--------
Scanner នេះធ្វើតែ SCAN + SAVE ប៉ុណ្ណោះ។
វាមិន Remove, Ban ឬកែថ្ងៃ VIP របស់សមាជិកណាម្នាក់ទេ។

វាទាញ Telegram ID / Name / Username / Role របស់សមាជិកដែល Telegram អនុញ្ញាតឲ្យ scanner មើលឃើញ
ហើយរក្សាទុកទៅ table telegram_members ក្នុង D1 ដែល MerRoeung Admin ប្រើស្រាប់។

សំខាន់
-------
Project នេះប្រើ npm package "telegram" (GramJS) ដូច្នេះមិនអាច Copy/Paste តែ file worker.js ក្នុង
Cloudflare Quick Editor ដូច Admin Worker បានទេ។ ត្រូវ Deploy តាម Cloudflare Builds + GitHub/GitLab។
មិនចាំបាច់ប្រើ CMD នៅកុំព្យូទ័ររបស់អ្នកទេ។

STEP 3A — Upload ZIP contents ទៅ GitHub
----------------------------------------
1. Extract ZIP នេះ។
2. ចូល github.com → New repository.
3. ដាក់ឈ្មោះ: merroeung-full-scanner
4. Create repository.
5. ចុច Add file → Upload files.
6. Drag files/folders ខាងក្នុង project នេះ:
      package.json
      wrangler.jsonc
      src/
7. Commit changes.

STEP 3B — ភ្ជាប់ Cloudflare Worker ទៅ GitHub
---------------------------------------------
បើអ្នកបានបង្កើត Worker "merroeung-full-scanner" រួច:
1. Cloudflare → Workers & Pages → merroeung-full-scanner
2. Settings → Builds
3. Connect to Git
4. ជ្រើស GitHub repo merroeung-full-scanner
5. Deploy command: npm run deploy
6. Save / Deploy

បើ Cloudflare មិនអនុញ្ញាត connect Worker ចាស់:
Workers & Pages → Create application → Import a repository
→ ជ្រើស merroeung-full-scanner → Save and Deploy.

STEP 3C — ដាក់ Secrets
-----------------------
Cloudflare → merroeung-full-scanner → Settings → Variables and Secrets

បង្កើត Secret:
TG_API_ID
TG_API_HASH
TELEGRAM_BOT_TOKEN
SCANNER_PASSWORD

TG_API_ID = API ID ពី my.telegram.org
TG_API_HASH = API hash ពី my.telegram.org
TELEGRAM_BOT_TOKEN = Token របស់ MerRoeung Admin bot
SCANNER_PASSWORD = Password ថ្មីសម្រាប់បើក Scanner page
ឧ. សរសេរ password ខ្លាំងមួយដោយខ្លួនឯង។

កុំផ្ញើ API hash, Bot Token ឬ Scanner Password ទៅអ្នកដទៃ។

STEP 3D — D1 Binding
--------------------
Cloudflare → merroeung-full-scanner → Bindings → Add binding → D1 database

Variable name:
db

D1 Database:
ជ្រើស database ដដែលដែល merroeung-admin ប្រើ។

STEP 3E — Test
--------------
បើក:
https://YOUR-SCANNER-WORKER.workers.dev/api/health

ត្រូវឃើញ:
d1Binding: true
apiId: true
apiHash: true
botToken: true
password: true

STEP 3F — Scan All
------------------
1. បើក root URL របស់ merroeung-full-scanner.
2. ដាក់ SCANNER_PASSWORD.
3. ដាក់ Telegram Group ID ដែលចាប់ផ្តើមដោយ -100
   ឧ. -1004387639522
4. ចុច "Scan All & Save to D1".
5. រង់ចាំរហូតឃើញ SCAN SUCCESS.

Scanner រក្សា member ថ្មីជា status=unpaid។
បើ member មាន Record Paid/Expiry នៅ MerRoeung Admin រួច Scanner មិនលុប Plan,
Amount, Expiry ឬ status paid របស់គាត់ទេ។

Admins និង Bots ត្រូវបានកត់សម្គាល់ជា is_admin / is_bot ដើម្បីយើងអាច skip ពួកគេ
នៅពេលធ្វើ Bulk Remove ក្នុងជំហានក្រោយ។

ចំណាំអំពី Join Date
-------------------
Telegram អាចផ្តល់ participant date សម្រាប់សមាជិកខ្លះ។ បើមាន Scanner រក្សាទុកវា។
បើ Telegram មិនផ្តល់ original join date វានឹងមិនបង្កើតថ្ងៃក្លែងក្លាយទេ។

បន្ទាប់ពី Scan បានជោគជ័យ
-------------------------
កុំ Remove អ្នកណាសិន។
ត្រឡប់ទៅ MerRoeung Admin → Members ហើយពិនិត្យចំនួន Tracked Members មុន។
បន្ទាប់មកយើងអាចធ្វើ Step 4:
Paid / Unpaid review → Protect Paid → Bulk Remove Unpaid.
